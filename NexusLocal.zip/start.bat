@echo off
title Nexus Setup
setlocal enabledelayedexpansion

echo ============================================
echo  Nexus - Automatic Setup
echo ============================================
echo.

:: Check Python
where python >nul 2>&1
if errorlevel 1 (
    echo [!] Python 3.10+ not found.
    echo     Download from https://www.python.org/downloads/
    echo     Tick "Add to PATH" during install, then run this again.
    pause
    exit /b 1
)
echo [OK] Python found.

:: Check Node.js
where node >nul 2>&1
if errorlevel 1 (
    echo [!] Node.js 18+ not found.
    echo     Download from https://nodejs.org/
    echo     Then run this again.
    pause
    exit /b 1
)
echo [OK] Node.js found.

:: Download Nexus package if not present
if not exist "Nexus\server.py" (
    echo.
    echo Downloading Nexus...
    powershell -Command "Invoke-WebRequest -Uri 'https://github.com/xorudra/Nexus-Local/raw/main/Nexus-Full.zip' -OutFile 'Nexus-Full.zip'"
    if errorlevel 1 (
        echo [!] Download failed. Check your internet connection.
        pause
        exit /b 1
    )
    echo Extracting...
    powershell -Command "Expand-Archive -Path 'Nexus-Full.zip' -DestinationPath '.' -Force"
    del Nexus-Full.zip
    echo [OK] Downloaded and extracted.
) else (
    echo [OK] Nexus files found.
)

:: Setup Python deps
python -c "import cryptography" >nul 2>&1
if errorlevel 1 (
    echo Installing Python components...
    pip install cryptography --quiet
)

:: Setup engine .env
if not exist "Nexus\.env" (
    echo Configuring...
    copy "Nexus\.env.example" "Nexus\.env" >nul
    for /f %%i in ('node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"') do set ENC_KEY=%%i
    powershell -Command "(Get-Content 'Nexus\.env') -replace 'PASTE_64_CHAR_HEX_HERE', '!ENC_KEY!' | Set-Content 'Nexus\.env'"
)

:: Install engine deps
if not exist "Nexus\engine\server\node_modules" (
    echo Installing engine components (first run, please wait)...
    cd Nexus\engine\server
    call npm install --production >nul 2>&1
    cd ..\..\..
)

:: Start engine
echo.
echo Starting Nexus engine...
start "Nexus Engine" cmd /k "cd /d "%~dp0Nexus\engine\server" && set PORT=3001 && set HOST=127.0.0.1 && set FREEAPI_DB_PATH=%~dp0Nexus\engine-data\freeapi.db && set FREEAPI_CONFIG_PATH=%~dp0Nexus\engine\freellmapi.config.json && set FREEAPI_ENV_PATH=%~dp0Nexus\.env && node dist\index.js"

timeout /t 6 >nul

:: Start dashboard
echo Starting Nexus dashboard...
echo.
echo ============================================
echo  Open http://127.0.0.1:8080 in your browser
echo ============================================
echo.
start "Nexus Dashboard" cmd /k "cd /d "%~dp0Nexus" && python server.py"

echo Done! Keep both windows open while using Nexus.
pause
