# Nexus

Your personal AI dashboard. 19 providers, all on your machine.

## Start

Double-click **`start.bat`**. That's it.

On first run it sets everything up automatically. Two windows open — keep both open.

Then open **http://127.0.0.1:8080** in your browser.

## What you get

19 AI providers: HuggingFace, SiliconFlow, Zhipu, Cohere, Mistral, Cloudflare, Google, OpenRouter, Groq, NVIDIA, Pollinations, Kilo, OVH, AI Horde, plus 5 relay providers (OpenRouter, Gemini, Groq, NVIDIA, Pollinations).

## Requirements

- **Node.js 18+** — https://nodejs.org/
- **Python 3.10+** — https://www.python.org/downloads/ (tick "Add to PATH")

The start script will tell you if anything's missing.

## Security

Everything runs on your computer only. Keys are encrypted. Nothing leaves your machine except the AI requests you make.
