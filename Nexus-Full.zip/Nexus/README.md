# Nexus

Your personal AI dashboard — 19 providers, all on your machine.

## Setup

1. Install **Node.js 18+** from https://nodejs.org/
2. Install **Python 3.10+** from https://www.python.org/downloads/ (tick *Add to PATH*)
3. Download `NexusLocal.zip` from the [releases page](https://github.com/xorudra/Nexus-Local/releases)
4. Unzip anywhere
5. Double-click **`start.bat`**

That's it. Everything configures automatically on first run.

## First Run

1. Two windows open: **Nexus Engine** and **Nexus Dashboard** — keep both open
2. Open http://127.0.0.1:8080 in your browser
3. Set your password and enter your **Nexus API key** (shown in the Engine window on first run)
4. Done

## Providers (19)

- **14 AI providers** via the built-in engine: HuggingFace, SiliconFlow, Zhipu, Cohere, Mistral, Cloudflare, Google, OpenRouter, Groq, NVIDIA, Pollinations, Kilo, OVH, AI Horde
- **5 relay providers** (built-in): OpenRouter, Gemini, Groq, NVIDIA, Pollinations (keyless)

## Security

- Everything runs on localhost only
- Keys encrypted with AES-256
- No data leaves your machine except API calls you make
