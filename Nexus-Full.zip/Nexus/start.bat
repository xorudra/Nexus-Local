@echo off
title Nexus
cd /d "%~dp0"

echo ============================================
echo  Nexus - Your Personal AI Dashboard
echo ============================================
echo.

:: Check Python
where python >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python 3.10+ not found.
    echo Download from https://www.python.org/downloads/ (tick "Add to PATH")
    pause
    exit /b 1
)

:: Check Node.js
where node >nul 2>&1
if errorlevel 1 (
    echo ERROR: Node.js 18+ not found.
    echo Download from https://nodejs.org/
    pause
    exit /b 1
)

:: Setup engine .env on first run
if not exist ".env" (
    echo First run: setting up...
    copy ".env.example" ".env" >nul
    for /f %%i in ('node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"') do set ENC_KEY=%%i
    powershell -Command "(Get-Content '.env') -replace 'PASTE_64_CHAR_HEX_HERE', '%ENC_KEY%' | Set-Content '.env'"
)

:: Install engine dependencies if needed
if not exist "engine\server\node_modules" (
    echo Installing components (first run, please wait)...
    cd engine\server
    call npm install --production >nul 2>&1
    cd ..\..
)

:: Install Python deps if needed
python -c "import cryptography" >nul 2>&1
if errorlevel 1 (
    echo Installing Python components...
    pip install cryptography --quiet
)

:: Start the AI engine in background
echo Starting Nexus engine...
start "Nexus Engine" cmd /k "cd /d "%~dp0engine\server" && set PORT=3001 && set HOST=127.0.0.1 && set FREEAPI_DB_PATH=%~dp0engine-data\freeapi.db && set FREEAPI_CONFIG_PATH=%~dp0engine\freellmapi.config.json && set FREEAPI_ENV_PATH=%~dp0.env && node dist\index.js"

:: Wait for engine
timeout /t 6 >nul

:: Start dashboard
echo Starting Nexus dashboard...
echo.
echo Open http://127.0.0.1:8080 in your browser
echo.
start "Nexus Dashboard" cmd /k "cd /d "%~dp0" && python server.py"

echo Nexus is running! Two windows opened (engine + dashboard).
echo Keep both open while using Nexus.
pause
